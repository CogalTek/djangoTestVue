<template>
	<section>
		<h2>Vue 3 + Django 🎉</h2>
		<p>Ceci est rendu par Vue.</p>
		<p>Hello world</p>
	</section>
</template>

<script setup>
// rien pour le moment
</script>

<style scoped>
	h2 {
		margin: 1rem 0;
	}
</style>
